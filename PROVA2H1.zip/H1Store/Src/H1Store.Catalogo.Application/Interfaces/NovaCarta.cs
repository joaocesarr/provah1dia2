﻿using CartasPapaiNoel.Application.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CartasPapaiNoel.Application.Interfaces
{
    public class Carta
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public int Endereco { get; set; }




        public Carta(string nome, int valor, string naipe)
        {
            Nome = nome;
            Endereco = Endereco; ;


        }
    }


}

