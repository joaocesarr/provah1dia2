﻿using CartasPapaiNoel.Application.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CartasPapaiNoelApplication.Interfaces
{
   
    public interface INovaCartaService
    {
        NovaCarta CriarNovaCarta(string nome, int valor);
        void AtualizarNovaCarta(NovaCarta novacarta);
        void ExcluirNovaCarta(int novacartaId);
        NovaCarta ObterNovaCartaPorId(int novacartaId);
       
    }

   
    public interface ICartaService
    {
        Carta CriarCarta(string nome, int valor, string naipe);
        void AtualizarCarta(Carta carta);
        void ExcluirCarta(int cartaId);
        Carta ObterCartaPorId(int cartaId);
        
    }
