﻿using System;
using AutoMapper;
using CartasPapaiNoelApplication;
using System.Collections.Generic;
using CartasPapaiNoelApplication.Interfaces;
using System.Runtime.InteropServices;

namespace SuaAplicacao.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartasController : ControllerBase
    {
        private readonly ICartaService _cartaService;

        public CartasController(ICartaService cartaService)
        {
            _cartaService = cartaService;
        }

        [HttpGet]
        public ActionResult<IEnumerable<Carta>> ObterTodasAsCartas()
        {
            var cartas = _cartaService.ObterTodasAsCartas();
            return Ok(cartas);
        }

        [HttpPost]
        public ActionResult<Carta> CriarCarta([FromBody] Carta novaCarta)
        {
            var cartaCriada = _cartaService.CriarCarta(novaCarta.Nome, novaCarta.Valor, novaCarta.Naipe);
            return CreatedAtAction(nameof(ObterCartaPorId), new { id = cartaCriada.Id }, cartaCriada);
        }

        [HttpGet("{id}")]
        public ActionResult<Carta> ObterCartaPorId(int id)
        {
            var carta = _cartaService.ObterCartaPorId(id);
            if (carta == null)
            {
                return NotFound();
            }
            return Ok(carta);
        }
    }
}