﻿using CartasPapaiNoel.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CartasPapaiNoel.Domain.Interfaces
{
    // Interface para operações relacionadas a "novacartas"
    public interface INovaCartaService
    {
        NovaCarta CriarNovaCarta(string nome, int valor);
        void AtualizarNovaCarta(NovaCarta novacarta);
        void ExcluirNovaCarta(int novacartaId);
        NovaCarta ObterNovaCartaPorId(int novacartaId);
        // Outros métodos relacionados a "novacartas" aqui
    }

    // Interface para operações relacionadas a "cartas"
    public interface ICartaService
    {
        Carta CriarCarta(string nome, int valor, string naipe);
        void AtualizarCarta(Carta carta);
        void ExcluirCarta(int cartaId);
        Carta ObterCartaPorId(int cartaId);
        // Outros métodos relacionados a "cartas" aqui
    }
}
