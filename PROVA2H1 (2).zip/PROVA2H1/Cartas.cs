﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.ComponentModel.DataAnnotations;

namespace CartasDoPapaiNoel.Controllers
{
    [Route("api/cartas")]
    [ApiController]
    public class CartasController : ControllerBase
    {
        private const string CartasJsonFilePath = "cartas.json";

        [HttpPost]
        public IActionResult ReceberCarta([FromBody] Carta carta)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            
            if (carta.Idade > 15)
            {
                return BadRequest("A idade da criança não pode ser maior que 15 anos.");
            }

            
            var cartas = CarregarCartas();

          
            cartas.Add(carta);

            
            SalvarCartas(cartas);

            
            return Ok("Carta recebida com sucesso!");
        }

        [HttpGet]
        public IActionResult ListarCartas()
        {
           
            var cartas = CarregarCartas();

            return Ok(cartas);
        }

        private List<Carta> CarregarCartas()
        {
            List<Carta> cartas;

            if (System.IO.File.Exists(CartasJsonFilePath))
            {
                
                var json = System.IO.File.ReadAllText(CartasJsonFilePath);
                cartas = JsonSerializer.Deserialize<List<Carta>>(json);
            }
            else
            {
                
                cartas = new List<Carta>();
            }

            return cartas;
        }

        private void SalvarCartas(List<Carta> cartas)
        {
            
            var json = JsonSerializer.Serialize(cartas);
            System.IO.File.WriteAllText(CartasJsonFilePath, json);
        }
    }
}
