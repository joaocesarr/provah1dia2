﻿using System.ComponentModel.DataAnnotations;

public class Carta
{
    [Required]
    [StringLength(255, MinimumLength = 3)]
    public string NomeDaCrianca { get; set; }

    [Required]
    public Endereco Endereco { get; set; }

    [Required]
    [Range(1, 15, ErrorMessage = "A idade da criança deve ser entre 1 e 15 anos.")]
    public int Idade { get; set; }

    [Required]
    [StringLength(500)]
    public string TextoDaCarta { get; set; }
}
