﻿using CartasPapaiNoel.Domain.ValueObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CartasPapaiNoel.Domain.Entities
{
    public class Carta
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public int Endereco { get; set; }
       



        public Carta(string nome, int valor, string naipe)
        {
            Nome = nome;
            Endereco = Endereco; ;
            
        
        }
    }
}
