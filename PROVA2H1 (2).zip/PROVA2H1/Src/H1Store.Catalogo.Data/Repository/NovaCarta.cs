﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CartasPapaiNoel.Data.Repository
{
    public class NovaCartaService : INovaCartaService
    {
        private readonly IRepositorio<NovaCarta> _repositorio;

        public NovaCartaService(IRepositorio<NovaCarta> repositorio)
        {
            _repositorio = repositorio;
        }

        public NovaCarta CriarNovaCarta(string nome, int valor)
        {
            NovaCarta novaCarta = new NovaCarta(nome, valor);
            _repositorio.Adicionar(novaCarta);
            return novaCarta;
        }

        
    }
    public class CartaService : ICartaService
    {
        private readonly IRepositorio<Carta> _repositorio;

        public CartaService(IRepositorio<Carta> repositorio)
        {
            _repositorio = repositorio;
        }

        public Carta CriarCarta(string nome, int valor, string naipe)
        {
            Carta carta = new Carta(nome, valor, naipe);
            _repositorio.Adicionar(carta);
            return carta;
        }

        // Implemente os outros métodos do serviço Cartas aqui
    }
}
