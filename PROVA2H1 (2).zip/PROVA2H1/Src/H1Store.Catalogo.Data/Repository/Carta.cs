﻿using CartasPapaiNoel.Domain.Entities;
using CartasPapaiNoel.Domain.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CartasPapaiNoel.Data.Repository;
public interface IRepositorio<T>
{
    T ObterPorId(int id);
    void Adicionar(T entidade);
    void Atualizar(T entidade);
    void Excluir(int id);
    
}